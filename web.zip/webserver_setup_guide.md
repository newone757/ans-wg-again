# Web Server Setup Guide

## Overview

This playbook configures a hub-and-spoke web infrastructure where:
- **Frontend servers** accept public HTTP/HTTPS traffic and proxy it through WireGuard to origin servers
- **Origin servers** handle the actual application logic and are protected from direct public access
- All inter-server communication happens over the WireGuard tunnel
- You can mix and match web servers (Nginx, Caddy, Apache, Traefik) per host
- Custom headers allow you to obfuscate server fingerprints

## Architecture

```
Internet → Frontend VPS (Public IP) → WireGuard Tunnel → Origin VPS (Backend App)
           [Nginx/Caddy/Apache/Traefik]                  [Nginx/Caddy/Apache/Traefik]
           Ports: 80, 443, WG Port                       Ports: WG Port only
```

## Prerequisites

1. WireGuard must already be configured and running (use the wireguard playbook first)
2. Your inventory must include the necessary web server variables
3. Backend applications should be running on the origin servers on the specified ports

## Project Structure

```
webserver-ansible/
├── webserver_playbook.yml
├── inventory.yml
├── group_vars/
│   └── wireguard_servers/
│       └── vault.yml
└── templates/
    ├── nginx_frontend.conf.j2
    ├── nginx_origin.conf.j2
    ├── caddy_frontend.j2
    ├── caddy_origin.j2
    ├── apache_frontend.conf.j2
    ├── apache_origin.conf.j2
    ├── traefik_static_frontend.yml.j2
    ├── traefik_dynamic_frontend.yml.j2
    ├── traefik_static_origin.yml.j2
    ├── traefik_dynamic_origin.yml.j2
    └── traefik.service.j2
```

## Inventory Configuration

### Frontend Server Configuration

Each frontend server needs:
- `web_server`: Choice of `nginx`, `caddy`, `apache`, or `traefik`
- `origin_target`: Which origin server to proxy to (must match inventory hostname)
- `proxy_domains`: List of domains this frontend will handle
- `custom_headers`: (Optional) Custom response headers for fingerprint obfuscation

Example:
```yaml
frontend1:
  ansible_host: 23.213.45.66
  ansible_port: 2224
  ansible_user: admin3
  ansible_ssh_private_key_file: ~/.ssh/frontend1_key
  wireguard_private_ip: 10.0.0.11
  wireguard_public_ip: 23.213.45.66
  wireguard_port: 51822
  web_server: nginx
  origin_target: origin1
  proxy_domains:
    - example.com
    - www.example.com
  custom_headers:
    Server: "Apache/2.4.41"
    X-Powered-By: "PHP/7.4.3"
```

### Origin Server Configuration

Each origin server needs:
- `web_server`: Choice of `nginx`, `caddy`, `apache`, or `traefik`
- `server_domains`: List of domain configurations with backend ports
- `custom_headers`: (Optional) Custom response headers

Example:
```yaml
origin1:
  ansible_host: 192.0.2.10
  ansible_port: 2222
  ansible_user: admin1
  ansible_ssh_private_key_file: ~/.ssh/origin1_key
  wireguard_private_ip: 10.0.0.1
  wireguard_public_ip: 2.56.23.12
  wireguard_port: 51822
  web_server: nginx
  server_domains:
    - domain: example.com
      backend_port: 8080
    - domain: www.example.com
      backend_port: 8080
    - domain: blog.example.com
      backend_port: 8081
  custom_headers:
    Server: "Apache/2.4.41"
    X-Powered-By: "PHP/7.4.3"
```

## Installation Steps

### 1. Verify WireGuard is Running

Before deploying web servers, ensure WireGuard is active:

```bash
ansible wireguard_servers -m shell -a "wg show" --ask-vault-pass
```

Test connectivity between frontend and origin:

```bash
ansible frontend_servers -m shell -a "ping -c 3 10.0.0.1" --ask-vault-pass
```

### 2. Update Your Inventory

Add the web server configuration variables to your `inventory.yml` as shown in the examples above.

### 3. Create Template Directory

```bash
mkdir -p templates
```

Place all the template files in the `templates/` directory.

### 4. Run the Playbook

**Dry run (check mode):**
```bash
ansible-playbook webserver_playbook.yml --ask-vault-pass --check
```

**Execute the playbook:**
```bash
ansible-playbook webserver_playbook.yml --ask-vault-pass
```

**Run on specific hosts:**
```bash
ansible-playbook webserver_playbook.yml --ask-vault-pass --limit frontend1,origin1
```

### 5. Verify Installation

**Check web server status:**
```bash
# For Nginx
ansible wireguard_servers -m shell -a "systemctl status nginx" --ask-vault-pass

# For Caddy
ansible wireguard_servers -m shell -a "systemctl status caddy" --ask-vault-pass

# For Apache
ansible wireguard_servers -m shell -a "systemctl status apache2" --ask-vault-pass

# For Traefik
ansible wireguard_servers -m shell -a "systemctl status traefik" --ask-vault-pass
```

**Test HTTP redirect:**
```bash
curl -I http://your-frontend-ip
# Should return 301 redirect to HTTPS
```

**Test proxy connectivity:**
```bash
curl -k -H "Host: example.com" https://your-frontend-ip
```

## SSL/TLS Certificates

The playbook uses self-signed certificates by default. For production, you should:

### Option 1: Let's Encrypt with Certbot (Recommended for Nginx/Apache)

**For Nginx:**
```bash
ansible frontend_servers -m apt -a "name=certbot,python3-certbot-nginx state=present" --become --ask-vault-pass
ansible frontend_servers -m shell -a "certbot --nginx -d example.com -d www.example.com --non-interactive --agree-tos -m admin@example.com" --become --ask-vault-pass
```

**For Apache:**
```bash
ansible frontend_servers -m apt -a "name=certbot,python3-certbot-apache state=present" --become --ask-vault-pass
ansible frontend_servers -m shell -a "certbot --apache -d example.com -d www.example.com --non-interactive --agree-tos -m admin@example.com" --become --ask-vault-pass
```

### Option 2: Caddy Automatic HTTPS

Caddy can automatically obtain Let's Encrypt certificates. Update the Caddyfile template to use real domains instead of `tls internal`.

### Option 3: Manual Certificate Installation

Copy your certificates to the servers and update the template paths:
```bash
ansible-playbook deploy_certificates.yml --ask-vault-pass
```

## Custom Headers for Fingerprint Obfuscation

The `custom_headers` configuration allows you to modify server response headers to make your servers appear as different software. This helps with:
- Hiding actual web server software
- Confusing automated scanners
- Security through obscurity

### Common Header Configurations

**Appear as Apache:**
```yaml
custom_headers:
  Server: "Apache/2.4.41 (Ubuntu)"
  X-Powered-By: "PHP/7.4.3"
```

**Appear as IIS:**
```yaml
custom_headers:
  Server: "Microsoft-IIS/10.0"
  X-Powered-By: "ASP.NET"
```

**Appear as old Nginx:**
```yaml
custom_headers:
  Server: "nginx/1.14.0"
```

**Minimal disclosure:**
```yaml
custom_headers:
  Server: "webserver"
```

### Important Note for Nginx

Nginx requires the `headers-more-nginx-module` to modify the `Server` header. To install:

```bash
ansible nginx_servers -m apt -a "name=libnginx-mod-http-headers-more-filter state=present" --become --ask-vault-pass
```

Then restart Nginx. If this module is not available, the `Server` header modification will be ignored.

## Firewall Configuration

The playbook automatically configures UFW:

**Frontend servers:**
- Allow: 80/tcp (HTTP)
- Allow: 443/tcp (HTTPS)
- Allow: WireGuard port/udp

**Origin servers:**
- Allow: 80/tcp from 10.0.0.0/24 only (WireGuard network)
- Allow: 443/tcp from 10.0.0.0/24 only (WireGuard network)
- Deny: 80/tcp from public
- Deny: 443/tcp from public
- Allow: WireGuard port/udp

Verify UFW rules:
```bash
ansible wireguard_servers -m shell -a "ufw status numbered" --become --ask-vault-pass
```

## Backend Application Setup

Origin servers expect backend applications running on specified ports. Example backend applications:

### Simple Python HTTP Server (for testing)
```bash
ansible origin_servers -m shell -a "cd /var/www && python3 -m http.server 8080 &" --become --ask-vault-pass
```

### Node.js Application
```bash
# Install Node.js first
ansible origin_servers -m apt -a "name=nodejs,npm state=present" --become --ask-vault-pass

# Deploy and run your app on port 8080
```

### Docker Container (if you prefer Docker)
```bash
ansible origin_servers -m shell -a "docker run -d -p 8080:80 nginx:alpine" --become --ask-vault-pass
```

## Troubleshooting

### Check Web Server Logs

**Nginx:**
```bash
ansible nginx_servers -m shell -a "tail -n 50 /var/log/nginx/error.log" --become --ask-vault-pass
```

**Caddy:**
```bash
ansible caddy_servers -m shell -a "journalctl -u caddy -n 50" --become --ask-vault-pass
```

**Apache:**
```bash
ansible apache_servers -m shell -a "tail -n 50 /var/log/apache2/error.log" --become --ask-vault-pass
```

**Traefik:**
```bash
ansible traefik_servers -m shell -a "journalctl -u traefik -n 50" --become --ask-vault-pass
```

### Test Proxy Connection from Frontend

SSH into a frontend server and test:
```bash
curl -v http://10.0.0.1/
```

This should reach the origin server over WireGuard.

### Verify UFW Rules

```bash
ansible origin_servers -m shell -a "ufw status verbose" --become --ask-vault-pass
```

Origin servers should NOT allow public HTTP/HTTPS traffic.

### Check Port Listening

```bash
ansible wireguard_servers -m shell -a "ss -tlnp | grep -E ':(80|443|8080)'" --become --ask-vault-pass
```

### Test DNS Resolution

Make sure your domains point to the frontend servers' public IPs:
```bash
dig example.com +short
nslookup example.com
```

### Configuration File Validation

**Nginx:**
```bash
ansible nginx_servers -m shell -a "nginx -t" --become --ask-vault-pass
```

**Apache:**
```bash
ansible apache_servers -m shell -a "apache2ctl -t" --become --ask-vault-pass
```

**Caddy:**
```bash
ansible caddy_servers -m shell -a "caddy validate --config /etc/caddy/Caddyfile" --become --ask-vault-pass
```

## Adding New Domains

To add a new domain to an existing setup:

1. Update `inventory.yml` with the new domain
2. Ensure DNS points to the frontend server
3. Re-run the playbook:
```bash
ansible-playbook webserver_playbook.yml --ask-vault-pass --limit frontend1,origin1
```

## Security Recommendations

1. **Use Real SSL Certificates**: Replace self-signed certs with Let's Encrypt or commercial certificates
2. **Regular Updates**: Keep web server software updated
3. **Rate Limiting**: Configure rate limiting on frontend servers
4. **DDoS Protection**: Consider using Cloudflare or similar services in front of frontends
5. **Monitor Logs**: Set up log aggregation and monitoring
6. **Backup Configs**: The playbook doesn't backup configs yet - consider adding this
7. **Fail2ban**: Install fail2ban on frontend servers to block malicious IPs
8. **Security Headers**: Add security headers (HSTS, CSP, X-Frame-Options, etc.)

## Advanced Configuration

### Multiple Origin Servers

You can have different frontend servers point to different origin servers:

```yaml
frontend1:
  origin_target: origin1
  
frontend2:
  origin_target: origin2
```

### Load Balancing (Future Enhancement)

For high availability, you could extend the templates to include multiple origin servers in the backend pool.

### Web Application Firewall

Consider installing ModSecurity for Nginx/Apache:
```bash
ansible nginx_servers -m apt -a "name=libnginx-mod-security2 state=present" --become --ask-vault-pass
```

## Performance Tuning

### Nginx

Edit `/etc/nginx/nginx.conf` on frontend servers:
```nginx
worker_processes auto;
worker_connections 4096;
```

### Caddy

Caddy is pre-tuned for most use cases, but you can adjust:
```caddyfile
{
    max_request_body_size 100MB
}
```

### Connection Pooling

Most modern web servers maintain connection pools to backends. Ensure your backend applications can handle concurrent connections.

## Monitoring

Consider setting up monitoring for:
- Web server response times
- Error rates (4xx, 5xx)
- WireGuard tunnel status
- Backend application health
- Disk space and system resources

Tools: Prometheus, Grafana, Netdata, or commercial solutions.

## Maintenance

### Restarting Services

```bash
# Restart all web servers
ansible nginx_servers -m systemd -a "name=nginx state=restarted" --become --ask-vault-pass
ansible caddy_servers -m systemd -a "name=caddy state=restarted" --become --ask-vault-pass
ansible apache_servers -m systemd -a "name=apache2 state=restarted" --become --ask-vault-pass
ansible traefik_servers -m systemd -a "name=traefik state=restarted" --become --ask-vault-pass
```

### Updating Configuration

After modifying templates, re-run the playbook:
```bash
ansible-playbook webserver_playbook.yml --ask-vault-pass
```

The playbook is idempotent and will only make necessary changes.